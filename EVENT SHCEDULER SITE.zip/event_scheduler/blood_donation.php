<?php
   $NAME = $_POST['NAME'];
   $BLOOD_GROUP = $_POST['BLOOD_GROUP'];
   $COLLEGE_NAME = $_POST['COLLEGE_NAME'];
   $CITY = $_POST['CITY'];


//Database connection
$conn = new mysqli('localhost','root','','event_scheduler');
/*if($conn->connection_error)
{
    die('Connection Failed : '.$conn->connect_error);
}
else{ */
    $stmt = $conn->prepare("insert into blood_donation(NAME, BLOOD_GROUP, COLLEGE_NAME, CITY) values(?, ?, ?, ?) ");
    $stmt->bind_param("ssss",$NAME, $BLOOD_GROUP, $COLLEGE_NAME, $CITY);
    $stmt->execute();
    echo ".....$NAME you're form has been submitted....." . '<br>';
      
    $stmt->close();
    $conn->close();
//}
?>
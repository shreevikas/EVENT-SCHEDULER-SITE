<?php
	$firstName = $_POST['firstName'];
	$lastName = $_POST['lastName'];
	$sport = $_POST['sport'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$number = $_POST['number'];


	// Database connection
	$conn = new mysqli('localhost','root','','event_scheduler');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into intercollege_sports(firstName, lastName, sport, email, password, number) values(?, ?, ?, ?, ?, ?)");
		$stmt->bind_param("sssssi", $firstName, $lastName, $sport, $email, $password, $number);
		$execval = $stmt->execute();
		//echo $execval;
		echo ".....$firstName you're form has been submitted....." . '<br>';
        echo "*******$email*******";
		$stmt->close();
		$conn->close();
	}
?>
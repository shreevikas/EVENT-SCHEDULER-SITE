<?php
	$name = $_POST['name'];
    $age = $_POST['age'];
	$number = $_POST['number'];
    $email = $_POST['email'];
    $city = $_POST['city'];
   


	// Database connection
	$conn = new mysqli('localhost','root','','event_scheduler');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into sanitize (name, age, number, email, city) values(?, ?, ?, ?, ?)");
		$stmt->bind_param("siiss", $name, $age, $number, $email, $city,);
		$execval = $stmt->execute();
		//echo $execval;
		echo ".....$name you're form has been submitted....." . '<br>';
        echo "*******$email*******";
		$stmt->close();
		$conn->close();
	}
?>
<?php
   $name = $_POST['name'];
   $usn = $_POST['usn'];
   $email = $_POST['email'];
   $city = $_POST['city'];


//Database connection
$conn = new mysqli('localhost','root','','event_scheduler');
/*if($conn->connection_error)
{
    die('Connection Failed : '.$conn->connect_error);
}
else{ */
    $stmt = $conn->prepare("insert into tree_plantation (name, usn, email, city) values(?, ?, ?, ?) ");
    $stmt->bind_param("ssss",$name, $usn, $email, $city);
    $stmt->execute();
    echo ".....$name you're form has been submitted....." . '<br>';
        echo "*******$email*******";
    $stmt->close();
    $conn->close();
//}
?>
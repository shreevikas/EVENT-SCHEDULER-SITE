-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2022 at 06:50 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `event_scheduler`
--

-- --------------------------------------------------------

--
-- Table structure for table `blood_donation`
--

CREATE TABLE `blood_donation` (
  `id` int(11) NOT NULL,
  `NAME` varchar(20) NOT NULL,
  `BLOOD_GROUP` varchar(10) NOT NULL,
  `COLLEGE_NAME` varchar(50) NOT NULL,
  `CITY` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `blood_donation`
--

INSERT INTO `blood_donation` (`id`, `NAME`, `BLOOD_GROUP`, `COLLEGE_NAME`, `CITY`) VALUES
(5, 'Varun', 'B', 'Global', 'Bangalore');

-- --------------------------------------------------------

--
-- Table structure for table `intercollege_sports`
--

CREATE TABLE `intercollege_sports` (
  `id` int(11) NOT NULL,
  `firstName` varchar(25) NOT NULL,
  `lastName` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` bigint(25) NOT NULL,
  `number` bigint(10) NOT NULL,
  `sport` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `intercollege_sports`
--

INSERT INTO `intercollege_sports` (`id`, `firstName`, `lastName`, `email`, `password`, `number`, `sport`) VALUES
(4, 'Varun', 'gowda B N', 'Varun@gmail.com', 123456, 7022945398, 'Cricket');

-- --------------------------------------------------------

--
-- Table structure for table `marathon`
--

CREATE TABLE `marathon` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(3) NOT NULL,
  `number` bigint(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `marathon`
--

INSERT INTO `marathon` (`id`, `name`, `age`, `number`, `email`, `city`) VALUES
(17, 'Varun gowda B N', 21, 9448107414, 'varungowdabn0665@gmail.com', 'RR Nagar'),
(18, 'shreevikas', 21, 9448106777, 'shahab123@gmail.com', 'RR Nagar');

-- --------------------------------------------------------

--
-- Table structure for table `powerlifting`
--

CREATE TABLE `powerlifting` (
  `id` int(11) NOT NULL,
  `firstName` varchar(25) NOT NULL,
  `lastName` varchar(25) NOT NULL,
  `weight` varchar(40) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `number` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `powerlifting`
--

INSERT INTO `powerlifting` (`id`, `firstName`, `lastName`, `weight`, `email`, `password`, `number`) VALUES
(1, 'Varun', 'gowda B N', '60-70', 'Varun@gmail.com', '123456', 7022945398);

-- --------------------------------------------------------

--
-- Table structure for table `sanitize`
--

CREATE TABLE `sanitize` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `age` int(3) NOT NULL,
  `number` bigint(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `city` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sanitize`
--

INSERT INTO `sanitize` (`id`, `name`, `age`, `number`, `email`, `city`) VALUES
(1, 'Varun gowda B N', 21, 9448107414, 'varungowdabn0665@gmail.com', 'RR Nagar'),
(3, 'Varun ', 21, 9448106777, 'varungowdabn0665@gmail.com', 'RR Nagar'),
(4, 'shreevikas', 21, 9448106777, 'shahab123@gmail.com', 'RR Nagar');

-- --------------------------------------------------------

--
-- Table structure for table `tree_plantation`
--

CREATE TABLE `tree_plantation` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `usn` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `city` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tree_plantation`
--

INSERT INTO `tree_plantation` (`id`, `name`, `usn`, `email`, `city`) VALUES
(3, 'shreevikas', '1GA19CS144', 'varungowdabn0665@gmail.com', 'RR Nagar'),
(4, 'shreevikas', '1GA19CS144', 'shahab123@gmail.com', 'RR Nagar');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blood_donation`
--
ALTER TABLE `blood_donation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `intercollege_sports`
--
ALTER TABLE `intercollege_sports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `marathon`
--
ALTER TABLE `marathon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `powerlifting`
--
ALTER TABLE `powerlifting`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sanitize`
--
ALTER TABLE `sanitize`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tree_plantation`
--
ALTER TABLE `tree_plantation`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blood_donation`
--
ALTER TABLE `blood_donation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `intercollege_sports`
--
ALTER TABLE `intercollege_sports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `marathon`
--
ALTER TABLE `marathon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `powerlifting`
--
ALTER TABLE `powerlifting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sanitize`
--
ALTER TABLE `sanitize`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tree_plantation`
--
ALTER TABLE `tree_plantation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
